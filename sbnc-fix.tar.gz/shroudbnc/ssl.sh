#!/bin/bash

# Este script genera una clave privada y un certificado SSL auto-firmado
# para shroudBNC usando OpenSSL.

# --- CONFIGURACIÓN ---
# Directorio donde se guardarán los archivos.
# Asegúrate de que el usuario de shroudBNC tenga permisos de lectura aquí.
#OUTPUT_DIR="/etc/shroudBNC/ssl"
OUTPUT_DIR="/home/pell/sbnc"

# Nombre base de los archivos (ej. shroudBNC.key, shroudBNC.crt)
CERT_NAME="sbnc"

# Días de validez del certificado
DAYS_VALID=365

# Información para el certificado (puedes personalizar esto)
# Si dejas los campos en blanco, OpenSSL te preguntará interactivamente.
# Asegúrate de que el "Common Name" sea el nombre de host de tu servidor o un dominio.
COUNTRY="ES"         # Código de país (ej. ES, US)
STATE="Madrid"       # Estado o Provincia
CITY="Madrid"        # Ciudad
ORG="MyBNC"          # Organización
ORG_UNIT="IT"        # Unidad de Organización
COMMON_NAME="tu_dominio.com" # Importante: pon aquí el FQDN de tu servidor o un nombre descriptivo (ej. mi.bouncer.es)
EMAIL="admin@tu_dominio.com" # Email de contacto

# --- LÓGICA DEL SCRIPT ---

echo "Creando directorio de salida: $OUTPUT_DIR"
mkdir -p "$OUTPUT_DIR" || { echo "Error: No se pudo crear el directorio $OUTPUT_DIR"; exit 1; }

KEY_PATH="$OUTPUT_DIR/${CERT_NAME}.key"
CSR_PATH="$OUTPUT_DIR/${CERT_NAME}.csr"
CRT_PATH="$OUTPUT_DIR/${CERT_NAME}.crt"
PEM_PATH="$OUTPUT_DIR/${CERT_NAME}.pem"

echo "Generando clave privada (${KEY_PATH})..."
openssl genrsa -out "$KEY_PATH" 2048 || { echo "Error al generar la clave privada."; exit 1; }
chmod 600 "$KEY_PATH" # Permisos restrictivos para la clave

echo "Generando Certificado de Solicitud de Firma (CSR - ${CSR_PATH})..."
openssl req -new \
    -key "$KEY_PATH" \
    -out "$CSR_PATH" \
    -subj "/C=$COUNTRY/ST=$STATE/L=$CITY/O=$ORG/OU=$ORG_UNIT/CN=$COMMON_NAME/emailAddress=$EMAIL" || { echo "Error al generar el CSR."; exit 1; }

echo "Auto-firmando el certificado (${CRT_PATH}) por $DAYS_VALID días..."
openssl x509 -req \
    -days "$DAYS_VALID" \
    -in "$CSR_PATH" \
    -signkey "$KEY_PATH" \
    -out "$CRT_PATH" || { echo "Error al auto-firmar el certificado."; exit 1; }

echo "Combinando clave y certificado en un archivo PEM (${PEM_PATH})..."
cat "$KEY_PATH" "$CRT_PATH" > "$PEM_PATH"
chmod 600 "$PEM_PATH" # Permisos restrictivos para el archivo PEM

echo "Limpiando archivo CSR temporal (${CSR_PATH})..."
rm "$CSR_PATH"

echo "¡Certificados SSL generados con éxito en $OUTPUT_DIR!"
echo "Puedes usar $CRT_PATH (certificado) y $KEY_PATH (clave) o $PEM_PATH (combinado) en tu configuración de shroudBNC."
echo "Recuerda reiniciar shroudBNC después de actualizar la configuración."
